"""
Superposition engines
"""
