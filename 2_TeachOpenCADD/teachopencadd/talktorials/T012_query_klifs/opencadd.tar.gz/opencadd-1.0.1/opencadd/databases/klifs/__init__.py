"""
opencadd.databases.klifs module
"""

from .api import setup_local, setup_remote
