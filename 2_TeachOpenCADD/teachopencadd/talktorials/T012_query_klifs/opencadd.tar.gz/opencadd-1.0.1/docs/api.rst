API Documentation
=================

.. autosummary::
   :toctree: generated

   opencadd
   opencadd.structure.core
   opencadd.structure.superposition
   opencadd.structure.superposition.api
   opencadd.structure.superposition.cli
   opencadd.structure.superposition.engines.base
   opencadd.structure.superposition.engines.mda
   opencadd.structure.superposition.engines.mmligner
   opencadd.structure.superposition.engines.theseus
   opencadd.structure.superposition.sequences
   opencadd.utils

