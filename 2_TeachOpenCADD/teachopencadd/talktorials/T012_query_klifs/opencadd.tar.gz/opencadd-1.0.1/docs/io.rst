IO
==

Once you have installed the package, you will have access (among others) 
to the ``opencadd.io`` module.

This module offers a simple API to load a variety of input formats in the form of a variety of
output formats.

This module is very much work-in-progress and offers so far only a first round of input/output 
options.

Check out the following tutorial to explore the API.
