# Exploratory notebooks

This folder contains exploratory notebooks that may use the opencadd package and/or explore datasets like the KLIFS database.
